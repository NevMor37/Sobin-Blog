module.exports = {

mongodb:'mongodb://myblog:myblog1@ds016058.mlab.com:16058/myblog'
//mongodb:'mongodb://myblog:myblog@ds139327.mlab.com:39327/myblog'

}
